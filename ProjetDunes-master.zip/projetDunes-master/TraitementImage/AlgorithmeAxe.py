import numpy as np
from scipy.io.wavfile import write 
from math import sqrt, ceil
from numpy import asmatrix
from TraitementImage import ImageDune, GestionAxes, Filtrage

from tkinter import *
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

def TableauAltitudeDistance(NumeroAxe, MonImage = None, MethodeFiltrage="Aucun", NbValMoy=4, LesAxes = None, ImageAffichage = [0]):
	"""
	Fonction donnant les listes ListeDistance et ListeAltitude utilisé dans l'algorithme : :func:`DetectionDunesAxe`. \n
	
	
	:param NumeroAxe: Indice de l'axe devant être traité.
	:type NumeroAxe: int
	
	:param MonImage: Objet de la classe ImageDune contenant le fichier image.
	:type MonImage: ImageDune
	
	:param LesAxes: Liste contenant tous les axes tracés par l'utilisateur.
	:type LesAxes: Liste d'objets axes
	
	:param ImageAffichage: Objet de la classe PhotoImage issue de la bibliothèque Pillow, contenant l'image à afficher dans la fenetre principale.
	:type ImageAffichage: PhotoImage
	
	:return: ListeDistance, ListeAltitude : liste des hauteurs en cm pour chaque pixel de l'axe, liste des distances entre le point de départ de l'axe et chaque pixel de l'axe
	"""
	# On prepare les listes des coordonnées X et Y (distance par rapport au point de départ et altitude respectivement)
	ListeDistance = []
	ListeAltitude = []
		
	ImageOrigine = asmatrix(MonImage.getImage())
	AltitudeMinimum = MonImage.AltitudeMin
	ResolutionImage = float(MonImage.getResolutionAltitude())
		
	# On prélève les deux points définissant le tracé de l'axe
	PointA = LesAxes.InfosAxe(NumeroAxe).getPointDepart().getCoordonnees()
	PointB = LesAxes.InfosAxe(NumeroAxe).getPointArrive().getCoordonnees()
	
	# Si le courant va de droite à gauche (vers la gauche), le point A est celui le plus à droite des 2 (à verticalité égale, il est le plus en bas)
	if(MonImage.getSensCourantGauche() == True):
		if(PointA[0] < PointB[0] or (PointA[0] == PointB[0] and PointA[1] > PointB[1])):
			PointA = PointB
			PointB = LesAxes.InfosAxe(NumeroAxe).getPointDepart().getCoordonnees()
	else:
		# Sinon (courant de gauche à droite) on fait en sorte que le point A à gauche de B
		# (il est le plus haut placé des 2. Et si ils sont à la même hauteur, c'est celui le plus à gauche)     
		if(PointA[0] > PointB[0] or (PointA[0] == PointB[0] and PointA[1] > PointB[1])):
			PointA = PointB
			PointB = LesAxes.InfosAxe(NumeroAxe).getPointDepart().getCoordonnees()
		
	# Nous avons maintenant les points de départ et d'arrivée (sur la miniature)
	# transposons les coordonnées des points de la miniature affichée sur l'image en taille réelle
	# le ratio de l'image étant conservé, on n'a pas besoin de regarder le nombre de lignes et colonne de l'image d'origine et sa miniature
	# seuls les nombres de lignes OU de colonnes suffisent (pour les 2 images bien évidemment)
	PointDepart = []
	PointArrive = []
	PointDepart.append(int(PointA[0] * ImageOrigine.shape[0] / ImageAffichage.size[1]))
	PointDepart.append(int(PointA[1] * ImageOrigine.shape[0] / ImageAffichage.size[1]))
	PointArrive.append(int(PointB[0] * ImageOrigine.shape[0] / ImageAffichage.size[1]))
	PointArrive.append(int(PointB[1] * ImageOrigine.shape[0] / ImageAffichage.size[1]))
		
	#print("Départ : " + str(PointDepart))
	#print("Arrivé : " + str(PointArrive))
		
	# Regardons le nombre de pixels à l'horizontal/vertical pour passer du point de départ à l'arrivée
	DistanceX = abs(PointArrive[0] - PointDepart[0])
	DistanceY = abs(PointArrive[1] - PointDepart[1])
	
	if(DistanceX >= DistanceY):       
		# Notre point de référence (ici vertical) correspond à l'initialisation à la position verticale du point de départ
		PositionYReference = PointDepart[1]
		# Ces deux variables sont pour définir le premier et dernier pixels horizontaux pour la boucle (initialisation et condition de sortie)
		PositionXDepart = PointDepart[0]
		PositionXArrive = PointArrive[0]
		# Cette variable indique de combien devrait-on se déplacer sur la vertical si l'on se déplace de 1 en horizontal
		# comme il y a de forte chance que ce nombre ne soit pas un entier, on se retrouvera avec des décalages de 0.4 pixel par exemple
		# il sera utilisé avec la position verticale de référence pour déterminer le niveau vertical du pixel le plus adapté à prendre
		IncrementVertical = DistanceY / DistanceX

		# Cette valeur permet de seuiller quand le passage à la ligne suivante ou non pour le pixel à la colonne X
		SeuilPassageSuivant = 1 + (IncrementVertical/2)
		DirectionIncremet = 1
		DirectionBoucle = 1
			
		# Si le point de départ est verticalement plus faible (positionné plus haut dans l'image) que le point d'arrivé
		if(PointDepart[1] > PointArrive[1]):             
			DirectionIncremet = -1
		
		# Si le sens du courant est de la droite vers la gauche, le pixel de départ est alors plus à droite que celui d'arrivé (Depart[0] > Arive[0])
		# pour la boucle for on effectue une décrémentation
		if(MonImage.getSensCourantGauche() == True):
			DirectionBoucle = -1
			
		for X in range (PositionXDepart, PositionXArrive, DirectionBoucle):
			# On caste donc en int pour avoir une coordonnées vertiale du tableau de l'image
			# c'est la coordonnée choisie de base pour détermniter sur quelle ligne (verticalité) prendre le pixel sur la colonne X de l'image
			PositionPixelVertiChoisi = int(PositionYReference)
			# Comme PointDepart[1] < PointArrive[1]
			# notre position de référence est donc augmenté de la valeur incrémentale
			# Ainsi nous obtenons la position théorique du pixel que l'on doit prendre (c'est un nombre flottant)
			PositionYReference += IncrementVertical * DirectionIncremet
				   
			# Comme notre position théorique est un nombre flottant, nous allons savoir si le pixel que l'on doit prendre est sur le même niveau vertical précédemment ou non
			if PositionYReference >= (PositionPixelVertiChoisi + SeuilPassageSuivant * DirectionIncremet):
				PositionPixelVertiChoisi += 1 * DirectionIncremet
					
			# On ajoute la valeur du pixel de l'image dans sa liste dédiée
			ListeAltitude.append(AltitudeMinimum + ResolutionImage * ImageOrigine[PositionPixelVertiChoisi, X])
			# On ajoute la distance entre le point de départ, et celui du pixel que l'on vient d'ajouter ci-dessus (pythagore)
			ListeDistance.append(sqrt((X - PointDepart[0]) ** 2 + (PositionPixelVertiChoisi - PointDepart[1]) ** 2))
		
	else:
		# Ici c'est que le nombre de pixels à parcourir sur la verticale est plus grand que le nombre pour l'horizontal
		# Notre point de référence (ici horizontal) correspond donc à l'initialisation à la position horizontale du point de départ
		PositionXReference = PointDepart[0]
		# C'est deux variables sont pour définir le premier et dernier pixels verticaux pour la boucle (initialisation et condition de sortie)
		PositionYDepart = PointDepart[1]
		PositionYArrive = PointArrive[1]
		# Cette variable indique de combien devrait-on se déplacer à l'horizontal si l'on se déplace de 1 en vertical
		# comme il y a de forte chance que ce nombre ne soit pas un entier, on se retrouvera avec des décalages de 0.4 pixel par exemple
		# il sera utilisé avec la position de référence pour déterminer le niveau horizontal du pixel le plus adapté
		IncrementHorizontal = DistanceX / DistanceY
		
		# Cette valeur permet de seuiller quand le passage à la colonne suivante ou non pour le pixel à la ligne Y
		SeuilPassageSuivant = 1 + (IncrementHorizontal/2)
		DirectionBoucle = 1
		DirectionIncremet = 1
			
		if(PointDepart[1] > PointArrive[1]):
			DirectionBoucle = -1
		
		# Si le sens du courant est de la droite vers la gauche, c'est que horizontalement les pixels choisi auront des valeurs de + en + faible
		# pour tester la position horizon du pixel à prendre, on effectue une décrémentation
		if(MonImage.getSensCourantGauche() == True):
			DirectionIncremet = -1
			
		for Y in range (PositionYDepart, PositionYArrive, DirectionBoucle):
			# On suppose que le pixel que l'on va prendre sera sur le même niveau (horizontal ou vertical, celui qui n'est pas concerné par la boucle for)
			# On caste donc en int pour avoir une coordonnées dadu tableau de l'image
			PositionPixelHoriChoisi = int(PositionXReference)
			# Comme nous sommes dans le cas du courant qui se déplace vers la gauche,
			# notre position de référence est donc réduite de la valeur incrémentale
			# Ainsi nous obtenons la position théorique du pixel que l'on doit prendre (c'est un nombre flottant)
			PositionXReference += IncrementHorizontal * DirectionIncremet
					
			# Comme notre position théorique est un nombre flottant, nous allons savoir si le pixel que l'on doit prendre est sur le même niveau que précédemment ou non                    
			if PositionXReference >= (PositionPixelHoriChoisi + SeuilPassageSuivant * DirectionIncremet):
				PositionPixelHoriChoisi += 1 * DirectionIncremet
					
			# On ajoute la valeur du pixel de l'image dans sa liste dédiée
			ListeAltitude.append(AltitudeMinimum + ResolutionImage * ImageOrigine[Y, PositionPixelHoriChoisi])
			# On ajoute la distance entre le point de départ, et celui du pixel que l'on vient d'ajouter ci-dessus (pythagore)
			ListeDistance.append(sqrt((PositionPixelHoriChoisi - PointDepart[0]) ** 2 + (Y - PointDepart[1]) ** 2 ))
	
	#Export des données sous forme wav pour exploitation sous audacity
	np_data = np.array(ListeAltitude)
	data=np.interp(np_data, (np_data.min(), np_data.max()), (-1, +1))
	scaleAlt = np.int16(data/np.max(np.abs(data))*32767)
	write('axes.wav', 1, scaleAlt)
	
	#TRAITEMENTS SUR AXE : 
	
	
	#Lissage par filtrage passe bas MEILLEUR RESULTAT POUR L'INSTANT
	if (MethodeFiltrage=="Filtre passe bas"):
		ListeAltitudePB = Filtrage.passe_bas(ListeAltitude,0.25)
		#print(ListeAltitudePB)
		return ListeDistance, ListeAltitudePB
	
	#Lissage par moyennage 
	if (MethodeFiltrage=="Moyenne glissante"):
		ListeAltitudeMY = Filtrage.moyenne(ListeAltitude,NbValMoy)
		#print(ListeAltitudeMY)
		return ListeDistance, ListeAltitudeMY
	
	
	#Lissage par mediane
	if (MethodeFiltrage=="Mediane"):
		ListeAltitudeMD = Filtrage.mediane(ListeAltitude)
		#print(ListeAltitudeMD)
		return ListeDistance, ListeAltitudeMD
		
	
	
	# On retourne les deux listes de données sans filtrage si rien n'est selectionné
	return ListeDistance, ListeAltitude
	
	
def DetectionDunesAxe(NumeroAxe, MonImage = None, LesAxes = None, MethodeFiltrage="Aucun", NbValMoy=4, ImageAffichage = [0], SeuilDetectionDune = 0, ListeDune = []):
	"""
	Algorithme de detection des dunes sur l'axe sélectionné.
	
	:param NumeroAxe: Axe sélectionné par l'utilisateur.
	:type NumeroAxe: int
	
	:param MonImage: Objet de la classe ImageDune contenant le fichier image.
	:type MonImage: ImageDune
	
	:param LesAxes: Liste des arcs tracés par l'utilisateur.
	:type LesAxes: liste d'objets Arc
	
	:param ImageAffichage: Objet de la classe PhotoImage issue de la bibliothèque Pillow, contenant l'image à afficher dans la fenetre principale.
	:type ImageAffichage: PhotoImage
	
	:param SeuilDetectionDune: Seuil de détection des petites dunes.
	:param SeuilDetectionDune: int
	
	:param ListeDune: Liste où stocker les resultats de l'analyse des dunes.
	:type ListeDune: liste
	
	:return: Liste des dunes reperes sur l'axe au format [IdAxe, IdDune, LongueurOnde, Hauteur, Profondeur1, PicDune, Profondeur2, DistPic, PicDune].
	
	
	.. note:: 
		Principe de l'algorithme :  \n
		Parcourt sur la liste des hauteurs des pixels de l'axe jusqu'à trouver une valeur minimale (qui correspondra au premier creux de la dunes) \n
		Parcourt ensuite jusqu'à trouver une valeur haute (qui correspondra au pic de la dune) \n
		Parcourt ensuite jusqu'à trouver une deuxième valeur minimale (qui correspondra au deuxième creux) \n
		Grâce à ces trois points, l'algorithme décide s'il s'agit ou non d'une dune : \n
		-Soit la différence pic-premierCreux est supérieur au seuil de détection de dune : alors c'est une dune \n
		-Soit ce n'est pas une dune
	
	"""
	AltitudeMinimum = MonImage.getAltitudeMin()
	ResolutionImage = float(MonImage.getResolutionAltitude())
	
	#print("ResolutionImage = " + str(ResolutionImage))
		
	# Le seuil de hauteur minimum pour qualifier de dune
	# On ne peut pas directement exploiter la données renseignées par l'utilisateur du programme
	# On utilise donc le plus petit multiple de la résolution de l'image qui puisse au moins faire la hauteur désignée
	SeuilDetection = ceil(SeuilDetectionDune / ResolutionImage) * ResolutionImage
	# On calcul la valeur de l'altitude maximum, celle qui signifie que l'on est en surface
	AltitudeMax = AltitudeMinimum + ResolutionImage * 255
	ListeDistance, ListeAltitude = TableauAltitudeDistance(NumeroAxe, MonImage, MethodeFiltrage, NbValMoy, LesAxes, ImageAffichage)
		
	IdDune = 0
		
	# indice de parcours des tableaux
	i = 0
	NombreElements = len(ListeAltitude)
	PrecedenteValeur = 255
		
	# On enlève toutes les valeurs d'altitude maximal au debut (ne sont pas associé à des dunes, c'est du blanc → la surface)
	while( i < NombreElements and ListeAltitude[i] == AltitudeMax):
		i += 1
		
	# On cherche ensuite à atteindre un minimum (qui sera le premier creux de la dune)
	while(i < NombreElements and ListeAltitude[i] <= PrecedenteValeur):
		PrecedenteValeur = ListeAltitude[i]
		i += 1
			
	# Maintenant pour toutes les autres données restantes du tableau
	while (i < NombreElements):
			
		ProfondeurDune1 = ListeAltitude[i - 1]  # 'i - 1' car à l'indice 'i' on ne respecte plus la condition (du while au dessus consistant à obtenir des valeurs toujours plus petite)
		Dist1 = ListeDistance[i - 1] # Connaître à quelle distance (par rapport au début de l'axe) se trouve le premier creux de la dune
			
		while(i < NombreElements and ListeAltitude[i] >= PrecedenteValeur):
			PrecedenteValeur = ListeAltitude[i]
			i += 1
			
		PicDune = ListeAltitude[i - 1]  # 'i - 1' car à l'indice 'i' on ne respecte plus la condition (la valeur mesuré augmente continuellement)
		DistPic = ListeDistance[i - 1] # La distance où se trouve le pic
			
		# Si le pic de la dune possède le niveau d'altitude maximal, c'est que nous sommes en surface → ce n'est pas une dune ! 
		if(ListeAltitude[i - 1] == AltitudeMax):
			DistPic = -1 # On met la distance à -1 pour signaler que c'est pas une dune
		
		
		while(i < NombreElements and ListeAltitude[i] <= PrecedenteValeur):
			PrecedenteValeur = ListeAltitude[i]
			i += 1
			
		ProfondeurDune2 = ListeAltitude[i - 1]  # 'i - 1' car à l'indice 'i' on ne respecte plus la condition (la valeur mesuré diminue continuellement)
		Dist2 = ListeDistance[i - 1] # La distance où se trouve le 2ème creux
	
		# On calcule les distance entre les creux (1/2) et le pic de la dune
		Dist1 = DistPic - Dist1
		Dist2 -= DistPic # Dist2 = Dist2 - DistPic
		
		# Pour que l'on puisse juger si ce que l'on vient d'inspecter peut-être une dune, on peut déjà vérifier les distances mesurés
		if(DistPic != -1):
			if(Dist1 < Dist2): # si le 1er creux est plus proche du pic que le 2ème creux
				HauteurDune = PicDune - ProfondeurDune1
			elif(Dist1 > Dist2):
				HauteurDune = PicDune - ProfondeurDune2
			else:
				HauteurDune = PicDune - ((ProfondeurDune1 + ProfondeurDune2) / 2)
			
			LongeurOnde = min(Dist1, Dist2)
			
			#print("Distance1 = " + str(Dist1) + " Distance2 = " + str(Dist2))
			#print("HautPic = " + str(PicDune) + " ProfondeurDune1 = " + str(ProfondeurDune1) + " ProfondeurDune2 = " + str(ProfondeurDune2))
			#print("Hauteur dune = " + str(HauteurDune) + " Longueur d'onde = " + str(LongeurOnde))
				
			if(HauteurDune >= SeuilDetection):
				# * 100 pour mettre en cm
				ListeDune.append([NumeroAxe, IdDune, round(LongeurOnde,2), round(HauteurDune * 100, 2), round(ProfondeurDune1,2), round(PicDune,2), round(ProfondeurDune2,2), DistPic, PicDune])
				IdDune += 1 # On incrémente l'identifiant de la dune
					
	return ListeDune

def BilanDunesParAxe(ListeDesDunes = [], NombreAxes = 1):
	"""
	Fonction permettant de regrouper l'ensemble des resultats de tous les axes tracés.
	L'indice i du tableau correspond aux dunes de l'axe i.
	
	:param ListeDesDunes: Liste d'information sur les dunes.
	:type ListeDesDunes: liste au format [IdAxe, IdDune, LongueurOnde, Hauteur, Profondeur1, PicDune, Profondeur2, DistPic, PicDune]
	
	:param NombreAxes: Nombre d'axes tracés par l'utilisateur.
	:type NombreAxes: int
	
	:return: liste des informations sur les dunes par axe au format [IdAxe, NombreDuneAxe, LongueurOndeMoyenneAxe, HauteurMoyenneAxe].
	
	"""
	# Si il y a au moins une dune de référencé dans le tableau
	TableauBilanParAxe = [] # Tableau qui contiendra le nombre de dunes, la longeur d'onde et la hauteur moyenne des dunes par axe
	
	NombreDeDunesTotal = len(ListeDesDunes)
	j = 0 # Indice de la dune que l'on lit dans le tableau
	
	if (NombreDeDunesTotal > 0):
		IdAxe = ListeDesDunes[j][0] # On commence par lire les dunes faisant partie de celles qui sont rattachées au premier axe ayant au moins une dune
		
		for i in range (0, NombreAxes): # Pour chacun des axes pouvant être répertorié
			# Si nous sommes sur un axe qui ne possède pas de dune, Le tableau contiendra une ligne associé à cet axe avec des 0 comme résultats (nombre de dune, longeur d'onde moyenne, hauteur moyenne)
			if i != IdAxe:
				TableauBilanParAxe.append([i,0,0,0])
			else:
				# On prépare de quoi calculer les paramètres des dunes de l'axe concerné
				NombreDuneAxe = 0
				LongueurOndeMoyenneAxe = 0
				HauteurMoyenneAxe = 0
				while(i == IdAxe and j < NombreDeDunesTotal):
					NombreDuneAxe += 1
					LongueurOndeMoyenneAxe += ListeDesDunes[j][2]
					HauteurMoyenneAxe += ListeDesDunes[j][3]
					j += 1;
					if (j < NombreDeDunesTotal): # Si nous avons pas atteint la fin du tableau (on incrémente j néanmoins 	aqpour sortir du while)
						IdAxe = ListeDesDunes[j][0] # On passe à la dune suivante dans le tableau
				LongueurOndeMoyenneAxe = round(LongueurOndeMoyenneAxe/NombreDuneAxe, 2)
				HauteurMoyenneAxe = round(HauteurMoyenneAxe/NombreDuneAxe)
				
				TableauBilanParAxe.append([i, NombreDuneAxe, LongueurOndeMoyenneAxe, HauteurMoyenneAxe])
	# Si aucune dune n'est détecté, on ajoute alors des données nulles pour chacun des axes
	else:
		for i in range (0, NombreAxes):
			TableauBilanParAxe.append([i,0,0,0])
		
	return TableauBilanParAxe
			
def DetectionDunes(MonImage = None, LesAxes = None, MethodeFiltrage="Aucun", NbValMoy=4, ImageAffichage = [0], SeuilDetectionDune = 0):
	"""
	Fonction qui appelle la fonction :func:`DetectionDunesAxe` sur tous les axes tracés.
	
	:param MonImage: Objet de la classe ImageDune contenant le fichier image.
	:type MonImage: ImageDune
	
	:param LesAxes: Liste contenant tous les axes tracés par l'utilisateur.
	:type LesAxes: Liste d'objets axes
	
	:param ImageAffichage: Objet de la classe PhotoImage issue de la bibliothèque Pillow, contenant l'image à afficher dans la fenetre principale.
	:type ImageAffichage: PhotoImage
	
	:param SeuilDetectionDune: Seuil de détection des petites dunes.
	:param SeuilDetectionDune: int
	
	:return: Liste des informations sur tous les axes
	"""
	ListeTouteDunes = []
	for i in range (0, LesAxes.NombreAxes()):
		DetectionDunesAxe(i, MonImage, LesAxes, MethodeFiltrage, NbValMoy, ImageAffichage, SeuilDetectionDune, ListeTouteDunes)
					
	#ListeTouteDunes = array([[0,0,10,15],[0,1,2,4],[1,2,3,4]])    # valeur test pour des résultats sur 2 tracés
	return ListeTouteDunes
