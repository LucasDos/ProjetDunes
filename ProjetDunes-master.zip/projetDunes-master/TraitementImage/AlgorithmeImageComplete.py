import cv2
import numpy as np
from matplotlib import pyplot as plt

def FiltrageLaplacien(Image = None):
	"""
	.. warning:: 
		Module entièrement commenté.
		A ne pas utiliser.
		A supprimer ?
		
	"""
	#img = cv2.imread(Image.getPath(),0)
	#img = img.reshape(img.shape[0], img.shape[1])
	
	#plt.imshow(img,cmap = 'gray')
	#plt.show()
	pass