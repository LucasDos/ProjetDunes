from PyQt5 import QtCore, QtGui, QtWidgets
import sys



class moyGlissSetting(object):
    """Classe pour la gestion de la fenetre du reglage de la moyenne glissante. \n
	Permet de créer la fenetre qui permet de reglage de la methode moyenne glissante. \n
	La classe MoyenneGlissanteGUI hérite de la classe PyQt5 Frame.

	:param object : Objet de la classe frame, fenetre affiché à l'utilisateur.
	:type object : Frame

	"""
    def setupUi(self, moyGlissSetting):
        """
        Fonction d'initialisation de la fenetre.
        """
        # Creation de la fentre
        moyGlissSetting.setObjectName("moyGlissSetting")
        moyGlissSetting.resize(206, 120)
        self.label = QtWidgets.QLabel(moyGlissSetting)
        self.label.setGeometry(QtCore.QRect(10, 20, 191, 16))
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(False)
        font.setWeight(50)
        self.label.setFont(font)
        self.label.setObjectName("label")

        # Bouton pour enregistrer la valeur entree
        self.pushButton = QtWidgets.QPushButton(moyGlissSetting)
        self.pushButton.setGeometry(QtCore.QRect(10, 60, 191, 31))
        self.pushButton.setObjectName("pushButton")

        # spinBox pour choisir la valeur
        self.spinBox = QtWidgets.QSpinBox(moyGlissSetting)
        self.spinBox.setGeometry(QtCore.QRect(140, 20, 51, 22))
        self.spinBox.setObjectName("spinBox")
        self.spinBox.setMinimum(4)
        self.spinBox.setMaximum(10000)
        self.label_2 = QtWidgets.QLabel(moyGlissSetting)
        self.label_2.setGeometry(QtCore.QRect(10, 90, 191, 16))
        font = QtGui.QFont()
        font.setPointSize(7)
        self.label_2.setFont(font)
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(moyGlissSetting)
        self.label_3.setGeometry(QtCore.QRect(10, 100, 191, 16))
        font = QtGui.QFont()
        font.setPointSize(7)
        self.label_3.setFont(font)
        self.label_3.setAlignment(QtCore.Qt.AlignCenter)
        self.label_3.setObjectName("label_3")

        self.retranslateUi(moyGlissSetting)
        QtCore.QMetaObject.connectSlotsByName(moyGlissSetting)

    def retranslateUi(self, moyGlissSetting):
        	"""
    		Fonction de changement des affichages.
    		"""
        #Changement des affichages (nom fenetre, boutton, et texte)
        _translate = QtCore.QCoreApplication.translate
        moyGlissSetting.setWindowTitle(_translate("moyGlissSetting", "Réglage moyenne glissante"))
        self.label.setText(_translate("moyGlissSetting", "Nombre de valeurs:"))
        self.pushButton.setText(_translate("moyGlissSetting", "Valider"))
        self.label_2.setText(_translate("moyGlissSetting", "Validez pour enregistrer cette valeur"))
        self.label_3.setText(_translate("moyGlissSetting", "puis quittez cette fenêtre"))
