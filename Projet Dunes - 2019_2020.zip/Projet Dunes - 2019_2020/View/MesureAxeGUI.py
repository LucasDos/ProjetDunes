from PyQt5 import QtCore, QtGui, QtWidgets
import sys

from Controller import AlgorithmeAxe

class MesureAxe(object):
    """Classe pour la gestion de la fenetre MesureAxeGUI. \n
	Permet de visualiser tous les axes ainsi que leur caractéristiques(numero d'axe,longueur...) . \n
	La classe MesureAxeGUI hérite de la classe PyQt5.

	:param object : Objet de la classe frame, fenetre affiché à l'utilisateur.
	:type fenetre: Frame

	"""
    def setupUi(self, MesureAxe):
        # Creation de la fenetre
        """
		Fonction d'initialisation de la fenetre
		"""
        MesureAxe.setObjectName("MesureAxe")
        MesureAxe.resize(300, 335)
        self.label = QtWidgets.QLabel(MesureAxe)
        self.label.setGeometry(QtCore.QRect(20, 220, 261, 20))
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")

        #Affichage des resultats
        self.columnView = QtWidgets.QColumnView(MesureAxe)
        self.columnView.setGeometry(QtCore.QRect(20, 10, 261, 192))
        self.columnView.setObjectName("columnView")

        # Creatin de la spinBox pour selectionner un axe
        self.spinBox = QtWidgets.QSpinBox(MesureAxe)
        self.spinBox.setGeometry(QtCore.QRect(50, 240, 42, 22))
        self.spinBox.setObjectName("spinBox")

        # Initalisation du bouton de visualisation du profils des axes
        self.button_Visualisation = QtWidgets.QPushButton(MesureAxe)
        self.button_Visualisation.setGeometry(QtCore.QRect(150, 240, 131, 23))
        self.button_Visualisation.setObjectName("button_Visualisation")
        self.button_Visualisation.clicked.connect(self.aBtnVisu)

        self.label_2 = QtWidgets.QLabel(MesureAxe)
        self.label_2.setGeometry(QtCore.QRect(20, 270, 261, 20))
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setObjectName("label_2")

        # Initalisation du bouton de selection qui permet de visualiser l'axe selectioné
        self.button_Selection = QtWidgets.QPushButton(MesureAxe)
        self.button_Selection.setGeometry(QtCore.QRect(20, 290, 111, 23))
        self.button_Selection.setObjectName("button_Selection")
        self.button_Selection.clicked.connect(self.aBtnSelect)

        # Initalisation du bouton de visualisation de l'ensemble des axes créer
        self.button_AllAxe = QtWidgets.QPushButton(MesureAxe)
        self.button_AllAxe.setGeometry(QtCore.QRect(160, 290, 121, 23))
        self.button_AllAxe.setObjectName("button_AllAxe")
        self.button_AllAxe.clicked.connect(self.aBtnAll)

        self.retranslateUi(MesureAxe)
        QtCore.QMetaObject.connectSlotsByName(MesureAxe)

    def retranslateUi(self, MesureAxe):
            """
    		Fonction d'initialisation de la fenetre
    		"""
        _translate = QtCore.QCoreApplication.translate
        MesureAxe.setWindowTitle(_translate("MesureAxe", "Mesures sur Axes"))
        self.label.setText(_translate("MesureAxe", "Choix de l\'axe (numéro de l\'axe):"))
        self.button_Visualisation.setText(_translate("MesureAxe", "Visualiser profil de l\'axe"))
        self.label_2.setText(_translate("MesureAxe", "Exporter les mesures (.txt):"))
        self.button_Selection.setText(_translate("MesureAxe", "Axe sélectionné"))
        self.button_AllAxe.setText(_translate("MesureAxe", "Tout les axes"))

    def aBtnVisu(self):
            """
    		Fonction qui permet de visualiser le profil de l'axe selectioné.
            To-Do : Adapter à PyQt5
    		"""
        AxeChoisi = int(self.spinBox.value())
        XCoordonnee, YCoordonnee = AlgorithmeAxe.TableauAltitudeDistance(AxeChoisi, self.MonImage, self.MethodeFiltrage, self.NbValMoy, self.LesAxes, self.ImageAffichage)


    def aBtnSelect(self):
        """
        Fonction qui permet de selectionner l'axe.
        To-Do : Adapter à PyQt5
        """
        print("Select")

    def aBtnAll(self):
            """
    		Fonction d'afficher tous les axes.
            To-Do : Adapter à PyQt5
    		"""
        print("All")


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    form = QtWidgets.QWidget()
    ui = MesureAxe()
    ui.setupUi(form)
    form.show()
    sys.exit(app.exec_())
