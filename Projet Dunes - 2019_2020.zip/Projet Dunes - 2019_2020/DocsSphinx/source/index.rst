.. ProjetDunes documentation master file, created by
   sphinx-quickstart on Sat Nov 24 16:13:52 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Page de documentation du projet de reconnaissance de dunes
**********************************************************

.. toctree::
   :maxdepth: 2
   :caption: Contents
   
   Autodoc
   
   

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
