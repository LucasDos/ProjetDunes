# imports obligatoires
from PyQt5 import QtCore, QtGui, QtWidgets
import sys

from View import MainWindowGUI

app = QtWidgets.QApplication(sys.argv)
MainWindow = QtWidgets.QMainWindow()
mw = MainWindowGUI.MainWindow()
mw.setupUi(MainWindow)
MainWindow.show()
sys.exit(app.exec_())
